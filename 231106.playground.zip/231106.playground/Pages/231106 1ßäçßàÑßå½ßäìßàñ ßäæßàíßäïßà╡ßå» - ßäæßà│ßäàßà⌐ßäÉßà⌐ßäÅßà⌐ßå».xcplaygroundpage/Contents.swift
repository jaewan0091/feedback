import UIKit

import Foundation

/*:
 ## 프로토콜(protocol) 소개 p.96

 타입이 구현해야 하는 요구사항을 정의하는 규칙들의 집합

 구조체, 클래스, 열거형이 반드시 포함해야 하는 메서드와 프로퍼티를 정의
 */

// 프로퍼티요구사항 , 메소드요구사항이 있음

protocol MessageBuilder {
    var name: String { get }
    func buildMessage() -> String
}

class MyClass: MessageBuilder {
    var name: String

    init(name: String) {
        self.name = name
    }

    func buildMessage() -> String {
        return "Hello " + name
    }
    
    //클래스에서의 타입매서드(static도 가능하긴함 class , static 둘다 가능하긴한데 구분을 위해 class 사용) ,  ( cfㅣ 구조체에서도 있음 그떈 static func를 사용함)
    
//   * static  타입프로퍼티, 타입매서드 등 제약을 제한을 둘떄 사용을 많이함 ( 유념해야할 개념.. )
    
    class func calcName(name:  String, str: String) -> String {
        return name + " " + str
    }
}

MyClass.calcName(name: "kim", str: "good")

/**
// 프로토콜 채택 예시
protocol 프로토콜이름 {
    // 프로토콜 정의부분(실제 인스턴스를 만들어 사용함 , 붕어빵의 틀을 만드는 곳임)
    var name: String { get }
    func buildMessage() -> String
}

class 클래스: 프로토콜이름 {
    //클래스 정의부분(실제 인스턴스를 만들어 사용함 , 붕어빵의 틀을 만드는 곳임)
    var name: String

    init(name: String) {
        self.name = name
    }

    func buildMessage() -> String {
        return "Hello " + name
    }
}

struct MyStruct: 프로토콜이름 {
    //구조체 정의
}

enum MyEnum: 프로토콜이름 {. // 열거형도 이렇게 사용할수 있다 !
    //열거형 정으
}
*/

//프로퍼티 요구사항
protocol MyProtocol {
    var fullName: String { get set }
    var mustBeValue: Int { get set }
    var doesNotNeedToValue: Int { get }//저장은 하지않고 값세팅시에 가지고만 올수 있어
}

protocol MyProtocolFullName {
    var fullName: String { get set }
}

//struct Mystruct: MyProtocol {
//    
//}
// 안됨: Type 'Mystruct' does not conform to protocol 'MyProtocol'
// 즉 구현해줘야함 , 만들어줘야함

struct MyStruct : MyProtocol {
    var fullName: String = ""
    var mustBeValue: Int {// getter setter도 구현읋 해줘야함
        get { return 0 }
        set { } // 인트값이 들어오는데 아무처리도 안하겠다는 것임
    }
    
    var doesNotNeedToValue: Int {
        get { return 0 }
    }
}

let my = MyStruct()
my.mustBeValue

//메서드 요구사항
protocol MyProtocolMethod {
    func random() -> Double  // 반환값을 Double로서 구현해라
}

struct MyMethod : MyProtocolMethod {
    func random() -> Double {
        return 0.0
    }
//    struct func goodMethod() -> String {
//        return "good"
    // 타입 메서드를 구조체에서 구현하기 위해서는 static func 로 시작함
    static func goodMethod() -> String {
           return "good"
    }
}

// 타입 매서드 요구사항을 강제화
protocol MyProtocolMethod2 {
    static func randomG() -> Double
}

struct MyMethod1: MyProtocolMethod, MyProtocolMethod2 {
    func random() -> Double {
        return 0.0
    }
    static func goodMethod() ->String {
        return "goog"
    }
    static func randomG() -> Double {
        return 1.1
    }
}

// 변경 매서드 요구사항 ( mutating method requirement )
//mutating? 특정 메소드 내에서 구조체 또는 열거형의 프로퍼티를 수정해야하는 경우, 해당 메소드의 동작을 변경하도록하는 것
protocol MyMutatingProtocol {
    var name:  String { get } // 여기서 set을 빼고
    // 가공이나 업데이트를 한다면?
    mutating func updateName(name: String) // 뺸부분을 여기에 추가
}

// 열거형
protocol Togglable {
   mutating func toggle() // 내부에 잇는 값을 동작을 시키는 것임(내부값이 변경됨)
    // muatiting을 하는 이유 어떤 녀석이 들어올지 모르니까
}

enum OnOffSwitch : Togglable {
    case off, on
    mutating func toggle() {
        // 이걸 정의하고 값을 내야함
        switch self { // 자기 자신에게의 의미
        case .off:
            self = .on
        case .on:
            self = .off
            // 걍우의수를 다 햇기에 default는 없어도됨
        }
    }
}

var myswitch = OnOffSwitch.on
// = var myswitch: OfOffSwitch = .on
myswitch.toggle()



//타입매서드
MyMethod.goodMethod()//바로 접근해서 사용 ( 인스턴스화, 메모리사용하지 않고 바로 접근 )

//인스턴스매서드
let myMethod = MyMethod()// 인스턴스를 생성해서 해야함 // 인스턴스메서드(일반적)
myMethod.random()


//초기화 구문 요구사항 (initializer Requirements)
protocol MyInitProtocol {
    init(str1: String, int1: Int) // 이러면 항상 초기화를 시켜줘야함 = 클래스 이어야겟죠?
}

class MyInitClass: MyInitProtocol {
    var str = ""
    var num = 0
    // required 필수 초기화 (상속할떄도 이걸 붙이면 강제화시킴)
    // 모든 하위 클래스가 해당 초기화 구문을 구현해야하 함을 강제
    required init(str1: String, int1: Int) { // required를 써서 구분해줘야함
        self.str = str1
        self.num = int1
    }
}

class MyContClass : MyInitClass {
    
}



print("end")

/**:
 # 구조체 (Structures) 소개 p.107

 클래스/구조체 모두 객체지향 프로그래밍의 기초를 형성하며

 데이터와 기능을 재사용할 수 있는 객체로 캡슐화하는 방법을 제공

 Switch Struct
 
 struct [구조체 이름]: [부모 클래스|구조체|프로토콜] {
   // 프로퍼티
   // 메서드
 }

 */

// 값 타입과 참조 타입 p.108~111
struct SampleStruct {
    var name: String

    init(name: String) {
        self.name = name
    }

    func buildHelloMsg() {
        "Hello " + name
    }
}

let myStruct1 = SampleStruct(name: "Park")
var myStruct2 = myStruct1
myStruct2.name = "Kim"
print( myStruct1.name )
print( myStruct2.name )


class SampleClass {
    var name: String

    init(name: String) {
        self.name = name
    }

    func buildHelloMsg() {
        "Hello " + name
    }
}

let myClass1 = SampleClass(name: "Park")
var myClass2 = myClass1
myClass2.name = "Kim"
print( myClass1.name )
print( myClass2.name )

// 그러면 구조체와 클래스는 언제 사용해야 될까? p.111
// 구조체는 멀티쓰레드에 안정적, Swift 안정성이 우선순위 1위
// 클래스는 리소스를 적게 사용

/*:
 ## 프로퍼티 래퍼 (Property Wrappers) p.115

 기본적으로 연산 프로퍼티의 기능을 개별 클래스/구조체와 분리하여 재사용

  (프로퍼티가 저장되는 방법을 관리하는 코드와 프로퍼티를 정의하는 코드 사이에 분리 계층을 추가)
 */


struct Address {
    private var cityname = ""

    var city: String {
        get { cityname }
        set { cityname = newValue.uppercased() }
    }
}

var address = Address()
address.city = "Lodon"
print( address.city )


@propertyWrapper
struct FixCase {
    private(set) var value: String = ""

    var wrappedValue: String {
        get { value }
        set { value = newValue.uppercased() }
    }

    init(wrappedValue initiaValue: String) {
        self.wrappedValue = initiaValue
    }
}

struct Contact {
    @FixCase var name: String
    @FixCase var city: String
}

var contract = Contact(name: "Park", city: "Seoul")
print(contract.name, contract.city)



// 예제1
protocol Greeting {
    var name: String { get }
    func sayHello()
}

struct Person: Greeting {
    var name: String


    func sayHello() {
        print("Hello, \(name)!") // 반환타입이 없어서 print로 ㄱ
    }
}
//...
let person = Person(name: "park")
person.sayHello()     // Hello, park!


//예제2

// 예시 코드:
protocol Shape {
    var area: Double { get }
}

class Circle: Shape {
    var radius: Double
    
    init(radius: Double) {
        self.radius = radius
    }
    
    var area: Double {
        get { // 원래 get 이 있는건데 생략이 가능
        return Double.pi * radius * radius // set이 없어서 return도 가능함
        }
    }
}

//예제3
protocol Vehicle {
    static func makeNoise()
}

struct Car : Vehicle {
    static func makeNoise() {
        print("부릉")
    }
}


//예제4
protocol Countable {
    static var count: Int { get set }
}

class Counter: Countable {
    static var count : Int  = 0
    
    static func incrementcount() {
        count += 1
    }
    static func decrementcount() {
        count -= 1
    }
}

print(Counter.count)

Counter.incrementcount()
print(Counter.count)

Counter.decrementcount()
print(Counter.count)


//예제5
struct Student: Equatable {
    var name: String
    var age: Int
    
    static func ==(lhs: Self, rhs: Self) -> Bool {
        return lhs.age == rhs.age
    }
    
    
//    static func ==(lhs: Student, rhs: Student) -> Bool {
//        return lhs.name == rhs.name && lhs.age == rhs.age
//    }
}


let alice = Student(name: "Alice", age: 20)
let bob = Student(name: "Bob", age: 21)

print(alice == bob) // false
// static func 없어도 == 의 default값이 잇어서 돌아가긴함 거기서 커스터마이징이 가능한것임
