//: [Previous](@previous)

import Foundation
//익스텐션


extension Double {
    // 리턴터입은 Double
    var squared: Double {
        return self * self
    }
    var cubed: Double {
        return self * self * self
    }
}

let myValue: Double = 3.0
print( myValue.squared)

//연산 프로퍼티
extension Int {
    var isEven: Bool {
        return self % 2 == 0
    }
}

let myNum = 2
myNum.isEven

2.isEven // 여기서 2는 구조체 객체로 사용된 것이다 (가능함)

protocol noExtension {
    var test: Int { get } //사용하세요라고 정의만한것임
    func testFunction(str: String) -> String
}

extension noExtension {// 프로토콜에 집어넣는다면? -- 동작이 되긴함
    var test: Int {
        get {
            return 7 //확장을 통해 기능을 추가해둠
        }
    }
    func testFunction(str: String)-> String {
        return "test \(str)"
    }
}

class MyExtensionClass : noExtension {
} // 구현하지않아도 디폴트로 기본으로 만들어지는게 생김

let myExtensionClass = MyExtensionClass()
myExtensionClass.test // 아무것도 구현이 되지 않았지만 .test가 가능해진 모습

//제공된 라이브러리에 확장을 하고싶을떄 활용아셈 (프로토콜 + 익스텐션)


//예제6(프로토콜예제)
protocol Person {
    var name: String { get }
    var age: Int { get}


    func introduce()
}

class Student: Person {
    var name: String
    var age: Int
    var school: String

    required init(name: String, age: Int, school: String) {
        self.school = school
        self.name = name
        self.age = age
    }

     func introduce() {
        print("I go to \(school).")
    }
}

let student1 = Student(name: "kim", age: 18, school: "highschool")
student1.introduce()


//예제7
//프로토콜을 채택하고 준수하는 클래스를 정의하고, 해당 클래스의 인스턴스를 생성하고 프로토콜의 메서드를 호출하는 코드를 작성해보세요.
//프로토콜의 이름은 Speaker이고, 인사말을 출력하는 메서드 speak(message: String)을 가지고 있습니다.
//protocol Greeter {
//    var name : String { get }
//    
//    func greet(name: String)
//}
//
//protocol Speaker {
//    func speak(name: String)
//}
//
//class Personq: Speaker, Greeter {
//    var name: String
//    init(name: String) {
//        self.name = name
//    }
// func speak(name: String) {
//        print("Hello, \(name)!")
//    }
//}

//let person = Personq(name: "John")
//person.speak(name: "Kim")


//예제8 -서브 프로토콜
protocol Animal {
    var name: String { get }
    func makeSound()
}

protocol Ani : Animal {   // 나중에 생길 구조체에 필요한것들중에서 기존 상위프로토콜의 내용은 제외하고 입력
    var owner: String { get }
    
}

struct Dog : Ani {
    var name: String
    var owner: String
    
    func makeSound()  {
        "Woof!"
    }
}

//...
let bob = Dog(name: "Bob", owner: "Charlie")
bob.makeSound()     // Woof!



//예제9
protocol Calculable {
    var value: Int { get set }
    static func add(_ a: Int, _ b: Int) -> Int
}
//
//class Calculator1 : Calculable {
//    var value : Int
//    
//    init(value: Int) {
//        self.value = value
//    }
//    
//    static func add(_ a: Int, _ b: Int)  {
//        return a + b
//    }
//    
//}

class Calculator1 : Calculable {
    var value: Int
    
    init() {
        self.value = 0
    }
    static func add(_ a: Int, _ b: Int) -> Int {
        return a + b
    }
    static func add(_ a: Calculator1, _ b: Int) -> Int {
        return a.value + b
    }
//    static func add(_ a: Calculator1, _ b: Int) -> Calculator1 {
//        return a.value += b
//    }
}

let calc = Calculator1()
Calculator1.add(3, 5)
calc.value = Calculator1.add(3,5)
Calculator1.add(calc, 8)


//예제10
//프로토콜을 확장하여 기본 구현을 제공하고, 해당 프로토콜을 채택하고 준수하는 열거형을 정의하세요.
protocol Colorful {
    var color: String { get }
    func describe()
}

extension Colorful {
    func describe() {
        print("This is \(color).")
    }
}
enum Fruit : Colorful {
    
    case apple, banana, cherry
    
    var color : String {
        switch self {
        case .apple:
            return "red"
        case .banana:
            return "yellow"
        case .cherry:
            return "pink"  // 메소드처럼 정리됨
        }
    }
}


let fruit = Fruit.apple
fruit.describe()        // This is red.
Fruit.banana.describe() // This is yellow.
Fruit.cherry.describe() // This is pin
