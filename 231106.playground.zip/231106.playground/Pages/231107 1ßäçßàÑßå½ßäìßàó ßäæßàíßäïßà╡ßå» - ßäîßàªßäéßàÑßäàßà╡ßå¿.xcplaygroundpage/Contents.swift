//: [Previous](@previous)

import Foundation

/**
 # 제너릭 ( Generics ) - "코드의 중복을 제거할 때 유용"
 - 스위프트에서는 여러 유형(타입)에도 작동하는 코드를 작성하고 해댱 유형에 대한 요구 사항을 지정하게 한다
 - Ex) Int타입 덧셈과 String타입의 덧셈은 서로 다르다 . 더하기의 개념은 바뀌는게 없는데  --> 타입과 상관없이 공통적으로 작동하게 하는 걸 설정해줌
 - 배열 , 스택 , Set 이런 라이브러리들은 제너릭타입, 제너릭함수임
 
 - [제너릭의 장점]
 - 어떤 타입에도 유연하게 대응할 수 있는 코드를 구현
 - 구현한 기능과 타입은 재사용하기 쉽고, 코드의 중복을 많이 줄일 수 있다 (-> 추상화될수있다 - 디테일이 직관적으로 보이지않을수 잇다)
 
 // 할떄 <타입 매개변수> 이것만 추가한다면 되는 부분임
 - 제너릭 타입:
   타입이름<타입 매개변수> :
 - 제너릭 메서드 :
   메서드 이름<타입 매개변수> (메서드 매개변수...) {함수}
 */

// 제너릭 함수
// <> 안에 들어간것은 모두 같은것임 (Any는 다 다르게 들어갈수잇음 조심) <T>, <Element> 통일만하면딤
func swapTwoValues<Element>(_ a: inout Element, _ b: inout Element) {
    let tampA = a
    a = b
    b = tampA
}

// 같은 Element타입이 들어와야함
var a = 12
var b = 345
// var b = 195.0 과 같은 Double타입이 나오면 오류발생=  a와 b가 다른타입이기 떄문임
swapTwoValues(&a, &b)
print( a, b)

var c = "Hello"
var d = "World"
swapTwoValues(&c, &d)
print( c, d)

var e = (1..<3) // Range type    cf) (1...3) = closeRange type
var f = (4..<6)
swapTwoValues(&e, &f)
print(e, f)


//제너릭 타입
struct Stack<Element> {
    var items: [Element] =  []
    mutating func push(_ item: Element) {
        items.append(item)
    }
    mutating func pop() -> Element {
        return items.removeLast()
    }
}

var myStack: Stack<Int> = Stack<Int>()
// =     var myStack = Stack<Int>()
    // Int타입의 스택을 만들겠다 이렇게되면 위의 Element자리에 모두 Int가 들어감
    // 그떄 결정이 나게 되는 것임 반환타입까지 ( mutating func pop() -> Int )
myStack.push(5)
myStack.push(10)
myStack.push(15)
myStack.items // Array<Int> 이렇게 되어있음 = 제너릭으로 되어있고 지금은 Int타입이라는 것이다
myStack.pop()


// AnyStack - 다른타입들 다들어감 - 단점: 꺼낼때마다 확인, 타입캐스팅해야함 그래서 같은타입을 넣어야 정신건강에 편함
var anyStack = Stack<Any>() // 아무거나 다담을수있음
anyStack.push("Hello") // String
anyStack.push(1.0) // Double
anyStack.push(5) // Int
anyStack.items


//제너릭 타입의 확장 (extension)   // 클래스는 상속인데 제너릭은 확장!
extension Stack {
    var topElement: Element? {
        return self.items.last
    }
}

// 확장이 먼저 들어감 그다음에 코드라인순서 차례대로 들어가는것임
myStack.topElement

// 제너릭 타입 제약 (프로토콜 또는 클래스) - 확장이 가능하기 때문
// T:   의 의미: 제약을 걸수가 있는것임 BinaryInteger protocol을 적용시킴
// 프로토콜을 주고 이 제약을 준수하는 애들만 나오게 한다는 것임 ( 그 메서드만 사용할수 있도록 함 )

//func swapTwoValues<T: BinaryInteger >(_ a: inout T, _ b: inout T) {
//    let tampA = a
//    a = b
//    b = tampA
//}



//제너릭 예제1
struct Stack1<T> {
    var items = [T]()
    mutating func push(_ item: T) {
        items.append(item)
    }
    mutating func pop() -> T {
        return items.removeLast()
    }
}

var intStack = Stack1<Int>()
intStack.push(3)
intStack.push(5)
print(intStack.pop())

var stringStack = Stack1<String>()
stringStack.push("Hello")
stringStack.push("World")
print(stringStack.pop())


//제너릭 예제2 swapTwo(&1, &2)를 보고 &에서 inout임읊 파악해야함
func swapTwo<T>(_ a: inout T, _ b: inout T ) { (a, b) = (b, a) }


var a2 = 10
var b2 = 20
swapTwo(&a2, &b2)
print(a2, b2) // 20, 10


//제너릭 예제3
/**
 # 내 풀이
struct Stack3<T> {
    var a: [T] = []
    
    mutating func push(_ num: T) {
        a.append(num)
    }
    mutating func pop() {
        a.removeLast()
    }
    mutating func peek() {
        a.
    }
    func isEmpty -> Bool {
        a.isEmpty? true : false
    }
    return a
}
*/

struct Stack3<T> {
    var a: [T] = []
    
    mutating func push(_ item: T) {
        return a.append(item)
    }
    mutating func pop() -> T? {
        if !a.isEmpty {
            return a.removeLast()
        } else {
            return nil
        }
    }
    mutating func peek() -> T? {
        if !a.isEmpty {
            return a.last
        } else {
            return nil
        }
    }
    var isEmpty: Bool {
        return a.isEmpty
    }
}

// 내풀이와 Feedback
//보통 mutating func에서의 매개변수는 item을 사용하는편이다.
// pop()에서 반환값을 T로 줘야하고 오류캐치해줘야함
// peek() 함수의 뜻은 스택의 맨위 항목을 반환하지만, 스택에서 제거하지 않는 것을 의미. 또한 스택이 비어있을경우 nil값 반환토록 구성
// isEmpty는 프로퍼티로 정의해야하며 스택이 비어있는지 여부를 나타내는 불리언값을 반환해야하므로 저렇게 표시해야함


var stack3 = Stack3<Int>()
stack3.push(1)
stack3.push(2)
stack3.push(3)
print(stack3.pop())   // 3
print(stack3.peek())  // 2
print(stack3.peek())  // 2
print(stack3.peek())  // 2
print(stack3.peek())  // 2
print(stack3.peek())  // 2
print(stack3.pop())
print(stack3.pop())
print(stack3.pop())
print(stack3.pop())
print(stack3.isEmpty) // false


// 제너릭 예제4

struct Queue<T> {
    var items: [T] = []
    
    mutating func enqueue(_ item: T) {
        items.append(item)              // append는 뒤에 계속 추가가 되는것임
    }
    
    mutating func dequeue() -> T? {
        if !items.isEmpty {
            return items.removeFirst() // 앞에서 뽑아 꺼내는것. vs   popLast() 뒤에서 뽑아 꺼내는 것
        }
        return nil
    }
    
     func front() -> T? {
        return items.first
    }
    
    var isEmpty : Bool {
        return items.isEmpty
    }
}
var queue = Queue<String>()
queue.enqueue("A")
queue.enqueue("B")
queue.enqueue("C")
print(queue.dequeue()) // A
print(queue.front()) // B
print(queue.isEmpty) // false


//제너릭 예제5

/**
 #내풀이:
func printType(_ a: T) -> String {
    print("The type of \(a) is \(a.type)")
}
*/

//func printType<T>(_ a: T) {
//    let typeString = String(describing: type(of: a))
//    print("The type of \(a) is \(typeString)")
//}
//  feedback
// return type ->String (x) ,  just blank (o)
//  put in <T> near by printType(func name)
//  printing type of 'a' work by "String(describing: type(of:a))"
// ** or T.self (o) or type(of: item) (o)

/**  # 강사님풀이  */
func printType<T>(_ value: T) {
    print( "The type of \(value) is \(T.self)")
}

printType(3) // The type of 3 is Int
printType("Hello") // The type of Hello is String
printType(true) // The type of true is Bool


//Generic example6

class Node1<Key, Value> {
    var key: Key
    var value: Value
    
    init(key: Key, value: Value) {
        self.key = key
        self.value = value
    }
}

//feed back
// don't try writing "" because of generic<T>

let node = Node1(key: "name", value: "Alice")
print(node.key) // name
print(node.value) // Alice


//Generic Example7

//func isEqual<T>(_ a: T, _ b: T) {
//    return  a == b ? true : false
//}

func isEqual<T: Equatable>(_ a: T, _ b: T) -> Bool {
    return a == b
}

/* 이렇게도 가능함  where T: Equatable
func isEqual<T>(_ a: T, _ b: T) -> Bool where T: Equatable {
    return a == b
}
 */


// feedback ( 함수의 반환 형식이 이전엔 Void인데, Bool 값을 반환해야함)

// 함수선언에서 T에 대한 Equatable 제약 조건을 추가하여 값들을 비교할 수 있도록 함
// ㄴAdded an Equatable constraint on T in the function declaration to allow comparison of values.
// 반환형식을 Bool로 변경해서 비교결과를 반환함
// ㄴChanged the return type to Bool to return the comparison result.
// 삼항 조건 연산자를 사용하는대신, a == b를 반환, 더 간결하게 만들수 있음
// ㄴReplaced the ternary conditional operator with a direct a == b comparison for a more concise expression.
print(isEqual(1, 1)) // true
print(isEqual("Hello", "World")) // false
print(isEqual(true, false)) // false



//Generic example08

//func isInt<T>(_ a: T) -> Bool {
//    let typeString = String(String(describing: type(of: a)))
//    return typeString == Int
//}

func isInt<T>(_ value: T) -> Bool {
    return value is Int
}

/*다른풀이1
 func isInt<T>(_ item: T) -> Bool {
     return type(of: item) == Int.self ? true : false
 }
 
 다른풀이2
 func isInt<T>(_ a: T) -> Bool {
     type(of: 1) == type(of: a)
 }
 */
// feedback
// a is Int 로 값이 어떤 타입(Int)유형인지 파익할 수 있다.

print(isInt(3)) // true
print(isInt("Hello")) // false
print(isInt(true)) // false


//Generic example09

//func castToInt<T>(_ a: T) -> Int? {
//    guard a is Int else{
//        return nil
//    }
//    return a
//}

func castToInt<T>(_ a: T) -> Int? {
    guard let intValue = a as? Int else {
        return nil
    }
    return intValue
}

/* 다른풀이1
 func castToInt<T>(_ a: T) -> Int? {
     if let intValue = a as? Int {
         return intValue
     } else {
         return nil
     }
 }
 
 다른풀이2_강사님
 func castToInt<T>(_ value: T) -> Int? {
    return value as? Int
}
 */
// as? 연산자를 사용하여 일관된 반환 형식을 사용_ 유형을 안전하게 캐스트할 수 있음
// a를 Int로 캐스트 시도할때 유용 - 성공하면 캐스트된 Int값을 반환 , 실패한경우에는 nil을 반환

print(castToInt(3)) // 3
print(castToInt("Hello")) // nil
print(castToInt(true)) // nil


// Generic example10

//func swapFirstAndLast<T>(_ a: inout [T]) -> [T] {
//    let one = a.first
//    let two = a.last
//    a.popFirst()
//    a.append(two)
//    a.popLast()
//    a.append(one)
//    
//    return a
//}

func swapFirstAndLast<T>(_ array: inout [T]) {
    if array.count >= 2 {
        array.swapAt(0, array.count-1)
    }
}


/* 다른풀이1
 func swapFirstAndLast<T>(_ items: inout [T]) {
     if let first = items.first, let last = items.last {
         items[0] = last
         items[items.count - 1] = first
     }
 }
 
 다른풀이2:
 func swapFirstAndLast<T>(_ array: inout [T]) {
     let last = array.count - 1
     (array[0], array[last]) = (array[last], array[0])
 }
 */

//feedback swapAt함수 활용
// 리턴타입이없음 - 안에서 값이 바뀌어버리기 떄문임
var array = [1, 2, 3, 4, 5]
swapFirstAndLast(&array)
print(array) // [5, 2, 3, 4, 1]

var array2 = ["A", "B", "C", "D"]
swapFirstAndLast(&array2)
print(array2) // ["D", "B", "C", "A"]


// Generic example11

func printReverse<T>(_ a: [T]) {
    let b = a.reversed()
    for e in b {
        print(e)
    }
}


/*
 다른풀이1:
 func printReverse<T>(_ a: [T]) {
     for index in 0..<a.count {
         let reversedIndex = a.count - 1 - index
         print(a[reversedIndex])
     }
 }
 다른풀이2: stride
 func printReverse<T>(_ arr: [T]) {
    for i in stride(from: arr.count -1, through: 0, by -1) {
        print( arr[i] )
    }
 }

func printReverse<T>(_ arr: [T]) {
    var change: [T] = []
    for i in arr {
        change.insert(i, at: 0)
    }
    change.forEach{ print($0) 
 }
 
 */

// feedback
// 접근 다좋았는데 print(b를 하는게 아니라 e를 했어야함 반복문으로 접근하는것이므로)

let array10 = [1, 2, 3, 4, 5]
printReverse(array10)
// 5
// 4
// 3
// 2
// 1

let array12 = ["A", "B", "C", "D"]
printReverse(array12)
// D
// C
// B
// A


// Generic example12

class Node<T> {
    var value: T
    var next: Node?

    init(value: T) {
        self.value = value
    }
}

struct LinkedList<T> {
    private var head: Node<T>?

    mutating func append(_ value: T) {
        let newNode = Node(value: value)
        if head == nil {
            head = newNode
            return
        }

        var current = head
        while current?.next != nil {
            current = current?.next
        }
        current?.next = newNode
    }

    mutating func insert(_ value: T, at index: Int) {
        let newNode = Node(value: value)
        if index == 0 {
            newNode.next = head
            head = newNode
            return
        }

        var current = head
        var i = 0
        var previous: Node<T>?
        while current?.next != nil && i < index {
            previous = current
            current = current?.next
            i += 1
        }
        previous?.next = newNode
        newNode.next = current
    }

    mutating func remove(at index: Int) -> T? {
        if index == 0 {
            let value = head?.value
            head = head?.next
            return value
        }

        var current = head
        var i = 0
        var previous: Node<T>?
        while current?.next != nil && i < index {
            previous = current
            current = current?.next
            i += 1
        }
        previous?.next = current?.next
        return current?.value
    }

    func nodeAt(_ index: Int) -> Node<T>? {
        var current = head
        var i = 0
        while current?.next != nil && i < index {
            current = current?.next
            i += 1
        }
        return current
    }

}

// 예시 코드:
var list = LinkedList<Int>()
list.append(1)
list.append(2)
list.append(3)
list.insert(4, at: 1)
list.remove(at: 2)
print(list.nodeAt(0)?.value) // 1
print(list.nodeAt(1)?.value) // 4
print(list.nodeAt(2)?.value) // 3

//검색은 배열보다 느린데 리스트는 삽입삭제가 편하다
