//: [Previous](@previous)

import Foundation

/**
 # 서브스크립트(Subscript)
 
 콜렉션의 요소에 접근
  - 클래스 , 구조체, 열거형은 콜렉션/리스트/시퀀스의 멤버 요소에 접근할 수 있는 단축 표현인 서브스크립트를 가지고 있다.
 */

class MySubscriptsClass {
    var name: String = ""
    
    init(name: String) {
        self.name = name
    }
    
    func appendValue(str: String) -> String {
        return name + str
    }
}

// 이런 예가 있다고 가정하자.

//struct MySubscripts {
//    var name: String = ""
//    
//    func appendValue(str: String) -> String {
//        return name + str
//    }
//}
//
//let mysc = MySubscripts(name: "kim")
//mysc.appendValue(str: "Hello")


//struct MySubscripts {
//    var name: String = ""
//    
//    subscript(str: String) -> String {  //함수가 아닌 subcript로
//        return name + str
//    }
//}
//
//let mysc = MySubscripts(name: "kim")
//
//let result1 = mysc["Hello"]  // "kimHello"
//print(result1)

struct MySubscripts {
    var arr: [String] = []
    
    subscript(index: Int) -> String {
        return arr[index]
    }
}

let mysc = MySubscripts(arr: ["Park", "Kim", "Lee"])
mysc.arr[1]

extension String {
    
    subscript(reCount: Int) -> String {
        var str = ""
         for _ in 0..<reCount {
            str += self
        }
        return str
    }
}

print( "Hello "[5])

/**
#이렇게 서브스크립트를 쓰면 좋은이유 :

 설정과 검색을 위한 별도의 메서드 없이 인덱스로 값을 설정하고 조회하기 위해 서브 스크립트를 사용함
 직접적으로 배열처럼 사용할수 잇도록해줌
 예) someArray[index] 로 Array 인스턴스에 요소를 접근하고 someDictionary[key]로 Dicktionary인스턴스에 요소를 접근시킬수 있다.

#쉽게 축약표현을 만들어줌
*/




// 예제11
protocol Animal {
    var name: String { get }
    func makeSound()
}

class Dog: Animal {
    var name: String

    init(name: String) {
        self.name = name
    }

    func makeSound() {
        print("Woof!")
    }
}

struct Cat: Animal {
    var name: String

    func makeSound() {
        print("Meow!")
    }
}

enum Bird: Animal {
    case parrot(String)
    case sparrow(String)

    var name: String {
        switch self {
        case .parrot(let name):
            return name
        case .sparrow(let name):
            return name
        }
    }

    func makeSound() {
        switch self {
        case .parrot:
            print("Hello!")
        case .sparrow:
            print("Chirp!")
        }
    }
}

extension Animal {  // Animal에 있는 name값을 활용한것 - 각자 값의 프로퍼티에 가지고 있는것임
    func introduce() {
        print("My name is \(name).")
    }
}


let dog = Dog(name: "Max")
let cat = Cat(name: "Lily")
let bird = Bird.parrot("Jack")

dog.introduce()     // My name is Max.
cat.introduce()     // My name is Lily.
bird.introduce()    // My name is Jack.



//예제12
protocol Flyable {
    var speed: Double { get set }
}

struct Bird1 : Flyable {
    var speed: Double // 프로토콜에 있으므로 가져와야함
}

extension Flyable {   // 확장은 프로토콜을 확장시키는것임 구조체를 확장시키는 개념이 아님
    func fly() -> String  {
        "Flying at \(speed)km/h"
    }
}

let bard = Bird1(speed: 30)
bard.fly()


//예제13
protocol Colorful {
    var color: String { get set }
}


struct Flower : Colorful{
    var color: String
}
//*원래 연산프로퍼티는 구조체에 저장프로퍼티를 만들어놓고 진행하는편인데 축약으로 진행하는 것임

extension Colorful {
    var description: String { //연산프로퍼티 추가
        get {
            return "A \(color) thing"
        }
    }
}
// 짥게 만들수도있음 extension Colorful { var description: String { "A \(color) thing" } }

let flower = Flower(color: "Yellow")
print(flower.description)     // A Yellow thing


//예제14
protocol Stackable {
    var items: [Int] { get set }
}

class Stack: Stackable {
    var items: [Int] //이런 배열이 하나 있어야한다는 것임
    
    init(items: [Int]) { // 구조체가 아니니 초기화 과정이 필요
        self.items = items
    }
}

extension Stackable {
    subscript(index: Int) -> Int {
        guard index >= 0 && index < items.count else {
            fatalError("Index out of range")
        }
        return items[index]
    }
}

let stack = Stack(items: [5,4,7,3,1])
print( stack[0] )   // 5
print( stack.items[0]) // 원래는 이렇게 접근해야하는데 Subscripts로 축약표현으로 되는 것임
//print( stack[7] ?? 0)  //이런식으로 옵셔널(5) 이렇게 뜨는걸 그냥 5로나오게 할 수 있다

/**
 #문자열 처리
 직접적으로 가져오지 않음
 */

//직접적으로 가져오는 방법 _ 되게 복잡함,, 238코드라인까지 )
let hello = "Hello" // < 이거는 캐릭터의 배열임
hello.startIndex // 처음의 인덱스넘버가 0번이 아닐수 잇음
// _rawBits 15가 뜸 -  이거부터 시작을한다는 것임

// 0번부터 접근하고싶다면?
hello[hello.startIndex]
//hello[hello.startIndex + 1] // 오류뜸 - 비트단위로 소개하고 복잡해지다보니까 안됨
hello.index(hello.startIndex, offsetBy: 1) //비트단위 계산을 도와줌
hello[hello.index(hello.startIndex, offsetBy: 1)]

//차라리 이렇게 꺼내오는게 편함
for c in hello {
    print(c)
}

// 73번문항이랑 겹칠 수 있음 - 사용할떄 알려줘야함 어디서 추가됬는지 체크시켜야함
//extension String {
//    subscript(index: Int) -> Character? {
//        guard index  < self.count else {
//            return nil
//        }
//        let i = self.index(self.startIndex, offsetBy: index)
//        return self[i]
//    }
//}
//
//hello[0]
//hello[1]
//hello[5]


// 클래스 참조를 카운팅하는게 있다고 함 - 안전한 코딩을 위한
